<?php

echo '<pre>';
//print_r($_GET);
print_r($_POST);

//http://localhost/7_forms/Aula_1


//http://localhost/7_forms/Aula_1/arquivo.php?email=teste%40teste.com&senha=12345

http://localhost/7_forms/Aula_1/arquivo.php