<?php
// Contantes
define("HOST", "localhost");
define("BANCO", "blog");
define("USUARIO", "root");
define("SENHA", "");