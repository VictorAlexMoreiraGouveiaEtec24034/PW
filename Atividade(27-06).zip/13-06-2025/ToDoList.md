# Atividade

- [ ] Fazer CRUD do arquivo noticia.php com o banco de dados MySQL
    - [ ] Inserir Autor
    - [ ] Inserir Título
    - [ ] Inserir Resumo
    - [ ] Inserir Conteúdo

1. Dentro de View, criar o diretório autores
2.Dentro de autores.
    - ListarAutores.php
    - noticia.php

- Criar as tabelas no banco de dados
    - autor
    - noticias

- Renomear a tabela Autor -> Autores -> innoDB

depois exportar a tabela do sistema para um arquivo .sql
