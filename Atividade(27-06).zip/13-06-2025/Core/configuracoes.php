<?php
// Contantes
define("HOST", "localhost");
define("BANCO", "blog");
define("USUARIO", "root");
define("SENHA", "");

define("DOMINIO", "http://localhost/13-06-2025/");
